﻿namespace PresentationLayer
{
    partial class DiseñoGimnasio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DiseñoGimnasio));
            this.membersBusinessBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.membersPage = new System.Windows.Forms.TabPage();
            this.membersOptionsGroupBox = new System.Windows.Forms.GroupBox();
            this.backButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.editButton = new System.Windows.Forms.Button();
            this.membersDataGridView = new System.Windows.Forms.DataGridView();
            this.membersGroupBox = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.addButton = new System.Windows.Forms.Button();
            this.estadosComboBox = new System.Windows.Forms.ComboBox();
            this.instalacionesComboBox = new System.Windows.Forms.ComboBox();
            this.membresiaComboBox = new System.Windows.Forms.ComboBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.numberPhoneTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.duiMemberTextBox = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.numberPhoneLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.duiLabel = new System.Windows.Forms.Label();
            this.instructorsPage = new System.Windows.Forms.TabPage();
            this.instructorsDataGridView = new System.Windows.Forms.DataGridView();
            this.optionsInstructorGroupBox = new System.Windows.Forms.GroupBox();
            this.goToEquipmentPageButton = new System.Windows.Forms.Button();
            this.goToAttendancesPageButton = new System.Windows.Forms.Button();
            this.goToFacilitiesPageButton = new System.Windows.Forms.Button();
            this.goToClassesPageButton = new System.Windows.Forms.Button();
            this.goToMembersPageButton = new System.Windows.Forms.Button();
            this.instructorDataGroupBox = new System.Windows.Forms.GroupBox();
            this.addInstructorButton = new System.Windows.Forms.Button();
            this.editInstructorButton = new System.Windows.Forms.Button();
            this.deleteInstructorButton = new System.Windows.Forms.Button();
            this.statusInstructorLabel = new System.Windows.Forms.Label();
            this.statusInstructorComboBox = new System.Windows.Forms.ComboBox();
            this.salaryInstructorTextBox = new System.Windows.Forms.TextBox();
            this.sueldoInstructorLabel = new System.Windows.Forms.Label();
            this.emailInstructorTextBox = new System.Windows.Forms.TextBox();
            this.phoneInstructorTextBox = new System.Windows.Forms.TextBox();
            this.lastNameInstructorTextBox = new System.Windows.Forms.TextBox();
            this.nameInstructorTextBox = new System.Windows.Forms.TextBox();
            this.emailInstructorLabel = new System.Windows.Forms.Label();
            this.phoneInstructorLabel = new System.Windows.Forms.Label();
            this.lastNameInstructorLabel = new System.Windows.Forms.Label();
            this.nameInstructorLabel = new System.Windows.Forms.Label();
            this.gymAdminTab = new System.Windows.Forms.TabControl();
            this.FacilitiesPage = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.equipmentPage = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.classesPage = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.attendancePage = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.membersBusinessBindingSource)).BeginInit();
            this.membersPage.SuspendLayout();
            this.membersOptionsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.membersDataGridView)).BeginInit();
            this.membersGroupBox.SuspendLayout();
            this.instructorsPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.instructorsDataGridView)).BeginInit();
            this.optionsInstructorGroupBox.SuspendLayout();
            this.instructorDataGroupBox.SuspendLayout();
            this.gymAdminTab.SuspendLayout();
            this.FacilitiesPage.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.equipmentPage.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.classesPage.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.attendancePage.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // membersBusinessBindingSource
            // 
            this.membersBusinessBindingSource.DataSource = typeof(BusinessLayer.CRUD.MembersBusiness);
            // 
            // membersPage
            // 
            this.membersPage.Controls.Add(this.membersOptionsGroupBox);
            this.membersPage.Controls.Add(this.membersDataGridView);
            this.membersPage.Controls.Add(this.membersGroupBox);
            this.membersPage.Location = new System.Drawing.Point(4, 4);
            this.membersPage.Name = "membersPage";
            this.membersPage.Padding = new System.Windows.Forms.Padding(3);
            this.membersPage.Size = new System.Drawing.Size(1158, 484);
            this.membersPage.TabIndex = 0;
            this.membersPage.Text = "Miembros";
            this.membersPage.UseVisualStyleBackColor = true;
            // 
            // membersOptionsGroupBox
            // 
            this.membersOptionsGroupBox.Controls.Add(this.backButton);
            this.membersOptionsGroupBox.Controls.Add(this.deleteButton);
            this.membersOptionsGroupBox.Controls.Add(this.editButton);
            this.membersOptionsGroupBox.Location = new System.Drawing.Point(8, 400);
            this.membersOptionsGroupBox.Name = "membersOptionsGroupBox";
            this.membersOptionsGroupBox.Size = new System.Drawing.Size(554, 69);
            this.membersOptionsGroupBox.TabIndex = 2;
            this.membersOptionsGroupBox.TabStop = false;
            this.membersOptionsGroupBox.Text = "Opciones";
            // 
            // backButton
            // 
            this.backButton.BackColor = System.Drawing.Color.LightCoral;
            this.backButton.FlatAppearance.BorderColor = System.Drawing.Color.Firebrick;
            this.backButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backButton.ForeColor = System.Drawing.SystemColors.Control;
            this.backButton.Location = new System.Drawing.Point(19, 25);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(82, 31);
            this.backButton.TabIndex = 6;
            this.backButton.Text = "Atras";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Click += new System.EventHandler(this.backMembersButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.BackColor = System.Drawing.Color.Red;
            this.deleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteButton.ForeColor = System.Drawing.SystemColors.Control;
            this.deleteButton.Location = new System.Drawing.Point(441, 25);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(87, 31);
            this.deleteButton.TabIndex = 5;
            this.deleteButton.Text = "Eliminar";
            this.deleteButton.UseVisualStyleBackColor = false;
            // 
            // editButton
            // 
            this.editButton.BackColor = System.Drawing.Color.Gold;
            this.editButton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.editButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.editButton.Location = new System.Drawing.Point(320, 25);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(87, 31);
            this.editButton.TabIndex = 4;
            this.editButton.Text = "Editar";
            this.editButton.UseVisualStyleBackColor = false;
            // 
            // membersDataGridView
            // 
            this.membersDataGridView.AllowUserToAddRows = false;
            this.membersDataGridView.AllowUserToDeleteRows = false;
            this.membersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.membersDataGridView.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.membersDataGridView.Location = new System.Drawing.Point(568, 17);
            this.membersDataGridView.MultiSelect = false;
            this.membersDataGridView.Name = "membersDataGridView";
            this.membersDataGridView.ReadOnly = true;
            this.membersDataGridView.RowTemplate.Height = 25;
            this.membersDataGridView.Size = new System.Drawing.Size(576, 452);
            this.membersDataGridView.TabIndex = 1;
            // 
            // membersGroupBox
            // 
            this.membersGroupBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.membersGroupBox.Controls.Add(this.label3);
            this.membersGroupBox.Controls.Add(this.label2);
            this.membersGroupBox.Controls.Add(this.label1);
            this.membersGroupBox.Controls.Add(this.addButton);
            this.membersGroupBox.Controls.Add(this.estadosComboBox);
            this.membersGroupBox.Controls.Add(this.instalacionesComboBox);
            this.membersGroupBox.Controls.Add(this.membresiaComboBox);
            this.membersGroupBox.Controls.Add(this.emailTextBox);
            this.membersGroupBox.Controls.Add(this.numberPhoneTextBox);
            this.membersGroupBox.Controls.Add(this.lastNameTextBox);
            this.membersGroupBox.Controls.Add(this.nameTextBox);
            this.membersGroupBox.Controls.Add(this.duiMemberTextBox);
            this.membersGroupBox.Controls.Add(this.emailLabel);
            this.membersGroupBox.Controls.Add(this.numberPhoneLabel);
            this.membersGroupBox.Controls.Add(this.lastNameLabel);
            this.membersGroupBox.Controls.Add(this.nameLabel);
            this.membersGroupBox.Controls.Add(this.duiLabel);
            this.membersGroupBox.Location = new System.Drawing.Point(8, 17);
            this.membersGroupBox.Name = "membersGroupBox";
            this.membersGroupBox.Size = new System.Drawing.Size(554, 375);
            this.membersGroupBox.TabIndex = 0;
            this.membersGroupBox.TabStop = false;
            this.membersGroupBox.Text = "DATOS DE MIEMBRO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(298, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 19);
            this.label3.TabIndex = 18;
            this.label3.Text = "Estado";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(298, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 19);
            this.label2.TabIndex = 17;
            this.label2.Text = "Instalacion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(298, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 19);
            this.label1.TabIndex = 16;
            this.label1.Text = "Membresia";
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addButton.Location = new System.Drawing.Point(431, 317);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(82, 31);
            this.addButton.TabIndex = 3;
            this.addButton.Text = "Agregar";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // estadosComboBox
            // 
            this.estadosComboBox.FormattingEnabled = true;
            this.estadosComboBox.Location = new System.Drawing.Point(298, 253);
            this.estadosComboBox.Name = "estadosComboBox";
            this.estadosComboBox.Size = new System.Drawing.Size(172, 27);
            this.estadosComboBox.TabIndex = 15;
            // 
            // instalacionesComboBox
            // 
            this.instalacionesComboBox.FormattingEnabled = true;
            this.instalacionesComboBox.Location = new System.Drawing.Point(298, 186);
            this.instalacionesComboBox.Name = "instalacionesComboBox";
            this.instalacionesComboBox.Size = new System.Drawing.Size(172, 27);
            this.instalacionesComboBox.TabIndex = 14;
            // 
            // membresiaComboBox
            // 
            this.membresiaComboBox.FormattingEnabled = true;
            this.membresiaComboBox.Location = new System.Drawing.Point(298, 119);
            this.membresiaComboBox.Name = "membresiaComboBox";
            this.membresiaComboBox.Size = new System.Drawing.Size(172, 27);
            this.membresiaComboBox.TabIndex = 13;
            // 
            // emailTextBox
            // 
            this.emailTextBox.Location = new System.Drawing.Point(45, 317);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(185, 26);
            this.emailTextBox.TabIndex = 12;
            // 
            // numberPhoneTextBox
            // 
            this.numberPhoneTextBox.Location = new System.Drawing.Point(45, 250);
            this.numberPhoneTextBox.Name = "numberPhoneTextBox";
            this.numberPhoneTextBox.Size = new System.Drawing.Size(185, 26);
            this.numberPhoneTextBox.TabIndex = 11;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(45, 183);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(185, 26);
            this.lastNameTextBox.TabIndex = 10;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(45, 119);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(185, 26);
            this.nameTextBox.TabIndex = 9;
            // 
            // duiMemberTextBox
            // 
            this.duiMemberTextBox.Location = new System.Drawing.Point(45, 56);
            this.duiMemberTextBox.Name = "duiMemberTextBox";
            this.duiMemberTextBox.Size = new System.Drawing.Size(185, 26);
            this.duiMemberTextBox.TabIndex = 8;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(45, 295);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(56, 19);
            this.emailLabel.TabIndex = 7;
            this.emailLabel.Text = "Correo";
            // 
            // numberPhoneLabel
            // 
            this.numberPhoneLabel.AutoSize = true;
            this.numberPhoneLabel.Location = new System.Drawing.Point(45, 228);
            this.numberPhoneLabel.Name = "numberPhoneLabel";
            this.numberPhoneLabel.Size = new System.Drawing.Size(67, 19);
            this.numberPhoneLabel.TabIndex = 6;
            this.numberPhoneLabel.Text = "Telefono";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(45, 161);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(66, 19);
            this.lastNameLabel.TabIndex = 5;
            this.lastNameLabel.Text = "Apellido";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(45, 97);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(65, 19);
            this.nameLabel.TabIndex = 4;
            this.nameLabel.Text = "Nombre";
            // 
            // duiLabel
            // 
            this.duiLabel.AutoSize = true;
            this.duiLabel.Location = new System.Drawing.Point(45, 34);
            this.duiLabel.Name = "duiLabel";
            this.duiLabel.Size = new System.Drawing.Size(33, 19);
            this.duiLabel.TabIndex = 3;
            this.duiLabel.Text = "DUI";
            // 
            // instructorsPage
            // 
            this.instructorsPage.Controls.Add(this.instructorsDataGridView);
            this.instructorsPage.Controls.Add(this.optionsInstructorGroupBox);
            this.instructorsPage.Controls.Add(this.instructorDataGroupBox);
            this.instructorsPage.Location = new System.Drawing.Point(4, 4);
            this.instructorsPage.Name = "instructorsPage";
            this.instructorsPage.Padding = new System.Windows.Forms.Padding(3);
            this.instructorsPage.Size = new System.Drawing.Size(1158, 484);
            this.instructorsPage.TabIndex = 5;
            this.instructorsPage.Text = "Intructores";
            this.instructorsPage.UseVisualStyleBackColor = true;
            // 
            // instructorsDataGridView
            // 
            this.instructorsDataGridView.AllowUserToAddRows = false;
            this.instructorsDataGridView.AllowUserToDeleteRows = false;
            this.instructorsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.instructorsDataGridView.Location = new System.Drawing.Point(468, 16);
            this.instructorsDataGridView.Name = "instructorsDataGridView";
            this.instructorsDataGridView.ReadOnly = true;
            this.instructorsDataGridView.RowTemplate.Height = 25;
            this.instructorsDataGridView.Size = new System.Drawing.Size(673, 462);
            this.instructorsDataGridView.TabIndex = 4;
            // 
            // optionsInstructorGroupBox
            // 
            this.optionsInstructorGroupBox.Controls.Add(this.goToEquipmentPageButton);
            this.optionsInstructorGroupBox.Controls.Add(this.goToAttendancesPageButton);
            this.optionsInstructorGroupBox.Controls.Add(this.goToFacilitiesPageButton);
            this.optionsInstructorGroupBox.Controls.Add(this.goToClassesPageButton);
            this.optionsInstructorGroupBox.Controls.Add(this.goToMembersPageButton);
            this.optionsInstructorGroupBox.Location = new System.Drawing.Point(3, 336);
            this.optionsInstructorGroupBox.Name = "optionsInstructorGroupBox";
            this.optionsInstructorGroupBox.Size = new System.Drawing.Size(450, 142);
            this.optionsInstructorGroupBox.TabIndex = 3;
            this.optionsInstructorGroupBox.TabStop = false;
            this.optionsInstructorGroupBox.Text = "Opciones";
            // 
            // goToEquipmentPageButton
            // 
            this.goToEquipmentPageButton.Location = new System.Drawing.Point(228, 83);
            this.goToEquipmentPageButton.Name = "goToEquipmentPageButton";
            this.goToEquipmentPageButton.Size = new System.Drawing.Size(107, 52);
            this.goToEquipmentPageButton.TabIndex = 4;
            this.goToEquipmentPageButton.Text = "Administrar Equipos";
            this.goToEquipmentPageButton.UseVisualStyleBackColor = true;
            this.goToEquipmentPageButton.Click += new System.EventHandler(this.goToEquipmentPageButton_Click);
            // 
            // goToAttendancesPageButton
            // 
            this.goToAttendancesPageButton.Location = new System.Drawing.Point(115, 84);
            this.goToAttendancesPageButton.Name = "goToAttendancesPageButton";
            this.goToAttendancesPageButton.Size = new System.Drawing.Size(107, 53);
            this.goToAttendancesPageButton.TabIndex = 3;
            this.goToAttendancesPageButton.Text = "Administrar Asistencias";
            this.goToAttendancesPageButton.UseVisualStyleBackColor = true;
            this.goToAttendancesPageButton.Click += new System.EventHandler(this.goToAttendancesPageButton_Click);
            // 
            // goToFacilitiesPageButton
            // 
            this.goToFacilitiesPageButton.Location = new System.Drawing.Point(285, 25);
            this.goToFacilitiesPageButton.Name = "goToFacilitiesPageButton";
            this.goToFacilitiesPageButton.Size = new System.Drawing.Size(107, 52);
            this.goToFacilitiesPageButton.TabIndex = 2;
            this.goToFacilitiesPageButton.Text = "Administrar Instalaciones";
            this.goToFacilitiesPageButton.UseVisualStyleBackColor = true;
            this.goToFacilitiesPageButton.Click += new System.EventHandler(this.goToFacilitiesPageButton_Click);
            // 
            // goToClassesPageButton
            // 
            this.goToClassesPageButton.Location = new System.Drawing.Point(172, 25);
            this.goToClassesPageButton.Name = "goToClassesPageButton";
            this.goToClassesPageButton.Size = new System.Drawing.Size(107, 52);
            this.goToClassesPageButton.TabIndex = 1;
            this.goToClassesPageButton.Text = "Administrar Clases";
            this.goToClassesPageButton.UseVisualStyleBackColor = true;
            this.goToClassesPageButton.Click += new System.EventHandler(this.goToClassesPageButton_Click);
            // 
            // goToMembersPageButton
            // 
            this.goToMembersPageButton.Location = new System.Drawing.Point(59, 26);
            this.goToMembersPageButton.Name = "goToMembersPageButton";
            this.goToMembersPageButton.Size = new System.Drawing.Size(107, 52);
            this.goToMembersPageButton.TabIndex = 0;
            this.goToMembersPageButton.Text = "Administrar Miembros";
            this.goToMembersPageButton.UseVisualStyleBackColor = true;
            this.goToMembersPageButton.Click += new System.EventHandler(this.goToMembersPageButton_Click);
            // 
            // instructorDataGroupBox
            // 
            this.instructorDataGroupBox.Controls.Add(this.addInstructorButton);
            this.instructorDataGroupBox.Controls.Add(this.editInstructorButton);
            this.instructorDataGroupBox.Controls.Add(this.deleteInstructorButton);
            this.instructorDataGroupBox.Controls.Add(this.statusInstructorLabel);
            this.instructorDataGroupBox.Controls.Add(this.statusInstructorComboBox);
            this.instructorDataGroupBox.Controls.Add(this.salaryInstructorTextBox);
            this.instructorDataGroupBox.Controls.Add(this.sueldoInstructorLabel);
            this.instructorDataGroupBox.Controls.Add(this.emailInstructorTextBox);
            this.instructorDataGroupBox.Controls.Add(this.phoneInstructorTextBox);
            this.instructorDataGroupBox.Controls.Add(this.lastNameInstructorTextBox);
            this.instructorDataGroupBox.Controls.Add(this.nameInstructorTextBox);
            this.instructorDataGroupBox.Controls.Add(this.emailInstructorLabel);
            this.instructorDataGroupBox.Controls.Add(this.phoneInstructorLabel);
            this.instructorDataGroupBox.Controls.Add(this.lastNameInstructorLabel);
            this.instructorDataGroupBox.Controls.Add(this.nameInstructorLabel);
            this.instructorDataGroupBox.Location = new System.Drawing.Point(3, 6);
            this.instructorDataGroupBox.Name = "instructorDataGroupBox";
            this.instructorDataGroupBox.Size = new System.Drawing.Size(450, 324);
            this.instructorDataGroupBox.TabIndex = 0;
            this.instructorDataGroupBox.TabStop = false;
            this.instructorDataGroupBox.Text = "DATOS DE INSTRUCTOR/ADMIN";
            // 
            // addInstructorButton
            // 
            this.addInstructorButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addInstructorButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addInstructorButton.ForeColor = System.Drawing.SystemColors.Control;
            this.addInstructorButton.Location = new System.Drawing.Point(275, 204);
            this.addInstructorButton.Name = "addInstructorButton";
            this.addInstructorButton.Size = new System.Drawing.Size(87, 31);
            this.addInstructorButton.TabIndex = 27;
            this.addInstructorButton.Text = "Agregar";
            this.addInstructorButton.UseVisualStyleBackColor = false;
            this.addInstructorButton.Click += new System.EventHandler(this.addInstructorButton_Click);
            // 
            // editInstructorButton
            // 
            this.editInstructorButton.BackColor = System.Drawing.Color.Gold;
            this.editInstructorButton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.editInstructorButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editInstructorButton.Location = new System.Drawing.Point(275, 241);
            this.editInstructorButton.Name = "editInstructorButton";
            this.editInstructorButton.Size = new System.Drawing.Size(87, 31);
            this.editInstructorButton.TabIndex = 4;
            this.editInstructorButton.Text = "Editar";
            this.editInstructorButton.UseVisualStyleBackColor = false;
            this.editInstructorButton.Click += new System.EventHandler(this.editInstructorButton_Click);
            // 
            // deleteInstructorButton
            // 
            this.deleteInstructorButton.BackColor = System.Drawing.Color.Red;
            this.deleteInstructorButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteInstructorButton.ForeColor = System.Drawing.SystemColors.Control;
            this.deleteInstructorButton.Location = new System.Drawing.Point(7, 277);
            this.deleteInstructorButton.Name = "deleteInstructorButton";
            this.deleteInstructorButton.Size = new System.Drawing.Size(87, 31);
            this.deleteInstructorButton.TabIndex = 5;
            this.deleteInstructorButton.Text = "Eliminar";
            this.deleteInstructorButton.UseVisualStyleBackColor = false;
            this.deleteInstructorButton.Click += new System.EventHandler(this.deleteInstructorButton_Click);
            // 
            // statusInstructorLabel
            // 
            this.statusInstructorLabel.AutoSize = true;
            this.statusInstructorLabel.Location = new System.Drawing.Point(240, 127);
            this.statusInstructorLabel.Name = "statusInstructorLabel";
            this.statusInstructorLabel.Size = new System.Drawing.Size(53, 19);
            this.statusInstructorLabel.TabIndex = 26;
            this.statusInstructorLabel.Text = "Estado";
            // 
            // statusInstructorComboBox
            // 
            this.statusInstructorComboBox.FormattingEnabled = true;
            this.statusInstructorComboBox.Location = new System.Drawing.Point(240, 149);
            this.statusInstructorComboBox.Name = "statusInstructorComboBox";
            this.statusInstructorComboBox.Size = new System.Drawing.Size(161, 27);
            this.statusInstructorComboBox.TabIndex = 25;
            // 
            // salaryInstructorTextBox
            // 
            this.salaryInstructorTextBox.Location = new System.Drawing.Point(301, 71);
            this.salaryInstructorTextBox.Name = "salaryInstructorTextBox";
            this.salaryInstructorTextBox.Size = new System.Drawing.Size(100, 26);
            this.salaryInstructorTextBox.TabIndex = 24;
            // 
            // sueldoInstructorLabel
            // 
            this.sueldoInstructorLabel.AutoSize = true;
            this.sueldoInstructorLabel.Location = new System.Drawing.Point(240, 74);
            this.sueldoInstructorLabel.Name = "sueldoInstructorLabel";
            this.sueldoInstructorLabel.Size = new System.Drawing.Size(55, 19);
            this.sueldoInstructorLabel.TabIndex = 23;
            this.sueldoInstructorLabel.Text = "Sueldo";
            // 
            // emailInstructorTextBox
            // 
            this.emailInstructorTextBox.Location = new System.Drawing.Point(7, 232);
            this.emailInstructorTextBox.Name = "emailInstructorTextBox";
            this.emailInstructorTextBox.Size = new System.Drawing.Size(185, 26);
            this.emailInstructorTextBox.TabIndex = 22;
            // 
            // phoneInstructorTextBox
            // 
            this.phoneInstructorTextBox.Location = new System.Drawing.Point(6, 169);
            this.phoneInstructorTextBox.Name = "phoneInstructorTextBox";
            this.phoneInstructorTextBox.Size = new System.Drawing.Size(185, 26);
            this.phoneInstructorTextBox.TabIndex = 21;
            // 
            // lastNameInstructorTextBox
            // 
            this.lastNameInstructorTextBox.Location = new System.Drawing.Point(7, 109);
            this.lastNameInstructorTextBox.Name = "lastNameInstructorTextBox";
            this.lastNameInstructorTextBox.Size = new System.Drawing.Size(185, 26);
            this.lastNameInstructorTextBox.TabIndex = 20;
            // 
            // nameInstructorTextBox
            // 
            this.nameInstructorTextBox.Location = new System.Drawing.Point(6, 49);
            this.nameInstructorTextBox.Name = "nameInstructorTextBox";
            this.nameInstructorTextBox.Size = new System.Drawing.Size(185, 26);
            this.nameInstructorTextBox.TabIndex = 19;
            // 
            // emailInstructorLabel
            // 
            this.emailInstructorLabel.AutoSize = true;
            this.emailInstructorLabel.Location = new System.Drawing.Point(7, 210);
            this.emailInstructorLabel.Name = "emailInstructorLabel";
            this.emailInstructorLabel.Size = new System.Drawing.Size(56, 19);
            this.emailInstructorLabel.TabIndex = 17;
            this.emailInstructorLabel.Text = "Correo";
            // 
            // phoneInstructorLabel
            // 
            this.phoneInstructorLabel.AutoSize = true;
            this.phoneInstructorLabel.Location = new System.Drawing.Point(6, 147);
            this.phoneInstructorLabel.Name = "phoneInstructorLabel";
            this.phoneInstructorLabel.Size = new System.Drawing.Size(67, 19);
            this.phoneInstructorLabel.TabIndex = 16;
            this.phoneInstructorLabel.Text = "Telefono";
            // 
            // lastNameInstructorLabel
            // 
            this.lastNameInstructorLabel.AutoSize = true;
            this.lastNameInstructorLabel.Location = new System.Drawing.Point(7, 87);
            this.lastNameInstructorLabel.Name = "lastNameInstructorLabel";
            this.lastNameInstructorLabel.Size = new System.Drawing.Size(66, 19);
            this.lastNameInstructorLabel.TabIndex = 15;
            this.lastNameInstructorLabel.Text = "Apellido";
            // 
            // nameInstructorLabel
            // 
            this.nameInstructorLabel.AutoSize = true;
            this.nameInstructorLabel.Location = new System.Drawing.Point(6, 27);
            this.nameInstructorLabel.Name = "nameInstructorLabel";
            this.nameInstructorLabel.Size = new System.Drawing.Size(65, 19);
            this.nameInstructorLabel.TabIndex = 14;
            this.nameInstructorLabel.Text = "Nombre";
            // 
            // gymAdminTab
            // 
            this.gymAdminTab.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.gymAdminTab.Controls.Add(this.instructorsPage);
            this.gymAdminTab.Controls.Add(this.membersPage);
            this.gymAdminTab.Controls.Add(this.FacilitiesPage);
            this.gymAdminTab.Controls.Add(this.equipmentPage);
            this.gymAdminTab.Controls.Add(this.classesPage);
            this.gymAdminTab.Controls.Add(this.attendancePage);
            this.gymAdminTab.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.gymAdminTab.HotTrack = true;
            this.gymAdminTab.Location = new System.Drawing.Point(0, -8);
            this.gymAdminTab.Multiline = true;
            this.gymAdminTab.Name = "gymAdminTab";
            this.gymAdminTab.SelectedIndex = 0;
            this.gymAdminTab.Size = new System.Drawing.Size(1166, 516);
            this.gymAdminTab.TabIndex = 0;
            this.gymAdminTab.Click += new System.EventHandler(this.backMembersButton_Click);
            // 
            // FacilitiesPage
            // 
            this.FacilitiesPage.Controls.Add(this.groupBox1);
            this.FacilitiesPage.Controls.Add(this.dataGridView1);
            this.FacilitiesPage.Controls.Add(this.groupBox2);
            this.FacilitiesPage.Location = new System.Drawing.Point(4, 4);
            this.FacilitiesPage.Name = "FacilitiesPage";
            this.FacilitiesPage.Padding = new System.Windows.Forms.Padding(3);
            this.FacilitiesPage.Size = new System.Drawing.Size(1158, 484);
            this.FacilitiesPage.TabIndex = 6;
            this.FacilitiesPage.Text = "Instalaciones";
            this.FacilitiesPage.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Location = new System.Drawing.Point(5, 399);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(554, 69);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opciones";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightCoral;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Firebrick;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(19, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 31);
            this.button1.TabIndex = 6;
            this.button1.Text = "Atras";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.backMembersButton_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.Control;
            this.button2.Location = new System.Drawing.Point(441, 25);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 31);
            this.button2.TabIndex = 5;
            this.button2.Text = "Eliminar";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gold;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button3.Location = new System.Drawing.Point(320, 25);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 31);
            this.button3.TabIndex = 4;
            this.button3.Text = "Editar";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.Location = new System.Drawing.Point(565, 16);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(576, 452);
            this.dataGridView1.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.comboBox3);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Location = new System.Drawing.Point(5, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(554, 375);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DATOS DE INSTALACIONES";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(298, 231);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 19);
            this.label4.TabIndex = 18;
            this.label4.Text = "Estado";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(298, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 17;
            this.label5.Text = "Instalacion";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(298, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 19);
            this.label6.TabIndex = 16;
            this.label6.Text = "Membresia";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LimeGreen;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Location = new System.Drawing.Point(431, 317);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 31);
            this.button4.TabIndex = 3;
            this.button4.Text = "Agregar";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(298, 253);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(172, 27);
            this.comboBox1.TabIndex = 15;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(298, 186);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(172, 27);
            this.comboBox2.TabIndex = 14;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(298, 119);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(172, 27);
            this.comboBox3.TabIndex = 13;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(45, 317);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(185, 26);
            this.textBox1.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(45, 250);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(185, 26);
            this.textBox2.TabIndex = 11;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(45, 183);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(185, 26);
            this.textBox3.TabIndex = 10;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(45, 119);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(185, 26);
            this.textBox4.TabIndex = 9;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(45, 56);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(185, 26);
            this.textBox5.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(45, 295);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 19);
            this.label7.TabIndex = 7;
            this.label7.Text = "Correo";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(45, 228);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 19);
            this.label8.TabIndex = 6;
            this.label8.Text = "Telefono";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 161);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 19);
            this.label9.TabIndex = 5;
            this.label9.Text = "Apellido";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(45, 97);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 19);
            this.label10.TabIndex = 4;
            this.label10.Text = "Nombre";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(45, 34);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 19);
            this.label11.TabIndex = 3;
            this.label11.Text = "DUI";
            // 
            // equipmentPage
            // 
            this.equipmentPage.Controls.Add(this.groupBox3);
            this.equipmentPage.Controls.Add(this.dataGridView2);
            this.equipmentPage.Controls.Add(this.groupBox4);
            this.equipmentPage.Location = new System.Drawing.Point(4, 4);
            this.equipmentPage.Name = "equipmentPage";
            this.equipmentPage.Padding = new System.Windows.Forms.Padding(3);
            this.equipmentPage.Size = new System.Drawing.Size(1158, 484);
            this.equipmentPage.TabIndex = 7;
            this.equipmentPage.Text = "Equipos";
            this.equipmentPage.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Location = new System.Drawing.Point(5, 399);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(554, 69);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Opciones";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.LightCoral;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Firebrick;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.SystemColors.Control;
            this.button5.Location = new System.Drawing.Point(19, 25);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(82, 31);
            this.button5.TabIndex = 6;
            this.button5.Text = "Atras";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.backMembersButton_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Red;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.SystemColors.Control;
            this.button6.Location = new System.Drawing.Point(441, 25);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(87, 31);
            this.button6.TabIndex = 5;
            this.button6.Text = "Eliminar";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Gold;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button7.Location = new System.Drawing.Point(320, 25);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 31);
            this.button7.TabIndex = 4;
            this.button7.Text = "Editar";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.Location = new System.Drawing.Point(565, 16);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowTemplate.Height = 25;
            this.dataGridView2.Size = new System.Drawing.Size(576, 452);
            this.dataGridView2.TabIndex = 4;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.comboBox4);
            this.groupBox4.Controls.Add(this.comboBox5);
            this.groupBox4.Controls.Add(this.comboBox6);
            this.groupBox4.Controls.Add(this.textBox6);
            this.groupBox4.Controls.Add(this.textBox7);
            this.groupBox4.Controls.Add(this.textBox8);
            this.groupBox4.Controls.Add(this.textBox9);
            this.groupBox4.Controls.Add(this.textBox10);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Location = new System.Drawing.Point(5, 16);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(554, 375);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "DATOS DE EQUIPOS";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(298, 231);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 19);
            this.label12.TabIndex = 18;
            this.label12.Text = "Estado";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(298, 164);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 19);
            this.label13.TabIndex = 17;
            this.label13.Text = "Instalacion";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(298, 97);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 19);
            this.label14.TabIndex = 16;
            this.label14.Text = "Membresia";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.LimeGreen;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button8.Location = new System.Drawing.Point(431, 317);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(82, 31);
            this.button8.TabIndex = 3;
            this.button8.Text = "Agregar";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(298, 253);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(172, 27);
            this.comboBox4.TabIndex = 15;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(298, 186);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(172, 27);
            this.comboBox5.TabIndex = 14;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(298, 119);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(172, 27);
            this.comboBox6.TabIndex = 13;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(45, 317);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(185, 26);
            this.textBox6.TabIndex = 12;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(45, 250);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(185, 26);
            this.textBox7.TabIndex = 11;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(45, 183);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(185, 26);
            this.textBox8.TabIndex = 10;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(45, 119);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(185, 26);
            this.textBox9.TabIndex = 9;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(45, 56);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(185, 26);
            this.textBox10.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(45, 295);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 19);
            this.label15.TabIndex = 7;
            this.label15.Text = "Correo";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(45, 228);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 19);
            this.label16.TabIndex = 6;
            this.label16.Text = "Telefono";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(45, 161);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 19);
            this.label17.TabIndex = 5;
            this.label17.Text = "Apellido";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(45, 97);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 19);
            this.label18.TabIndex = 4;
            this.label18.Text = "Nombre";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(45, 34);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 19);
            this.label19.TabIndex = 3;
            this.label19.Text = "DUI";
            // 
            // classesPage
            // 
            this.classesPage.Controls.Add(this.groupBox5);
            this.classesPage.Controls.Add(this.dataGridView3);
            this.classesPage.Controls.Add(this.groupBox6);
            this.classesPage.Location = new System.Drawing.Point(4, 4);
            this.classesPage.Name = "classesPage";
            this.classesPage.Padding = new System.Windows.Forms.Padding(3);
            this.classesPage.Size = new System.Drawing.Size(1158, 484);
            this.classesPage.TabIndex = 8;
            this.classesPage.Text = "Clases";
            this.classesPage.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button9);
            this.groupBox5.Controls.Add(this.button10);
            this.groupBox5.Controls.Add(this.button11);
            this.groupBox5.Location = new System.Drawing.Point(5, 399);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(554, 69);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Opciones";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.LightCoral;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.Firebrick;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.SystemColors.Control;
            this.button9.Location = new System.Drawing.Point(19, 25);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 31);
            this.button9.TabIndex = 6;
            this.button9.Text = "Atras";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.backMembersButton_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Red;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.ForeColor = System.Drawing.SystemColors.Control;
            this.button10.Location = new System.Drawing.Point(441, 25);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(87, 31);
            this.button10.TabIndex = 5;
            this.button10.Text = "Eliminar";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Gold;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button11.Location = new System.Drawing.Point(320, 25);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(87, 31);
            this.button11.TabIndex = 4;
            this.button11.Text = "Editar";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView3.Location = new System.Drawing.Point(565, 16);
            this.dataGridView3.MultiSelect = false;
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowTemplate.Height = 25;
            this.dataGridView3.Size = new System.Drawing.Size(576, 452);
            this.dataGridView3.TabIndex = 4;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.button12);
            this.groupBox6.Controls.Add(this.comboBox7);
            this.groupBox6.Controls.Add(this.comboBox8);
            this.groupBox6.Controls.Add(this.comboBox9);
            this.groupBox6.Controls.Add(this.textBox11);
            this.groupBox6.Controls.Add(this.textBox12);
            this.groupBox6.Controls.Add(this.textBox13);
            this.groupBox6.Controls.Add(this.textBox14);
            this.groupBox6.Controls.Add(this.textBox15);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label27);
            this.groupBox6.Location = new System.Drawing.Point(5, 16);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(554, 375);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "DATOS DE CLASE";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(298, 231);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 19);
            this.label20.TabIndex = 18;
            this.label20.Text = "Estado";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(298, 164);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 19);
            this.label21.TabIndex = 17;
            this.label21.Text = "Instalacion";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(298, 97);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 19);
            this.label22.TabIndex = 16;
            this.label22.Text = "Membresia";
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.LimeGreen;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button12.Location = new System.Drawing.Point(431, 317);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(82, 31);
            this.button12.TabIndex = 3;
            this.button12.Text = "Agregar";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(298, 253);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(172, 27);
            this.comboBox7.TabIndex = 15;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(298, 186);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(172, 27);
            this.comboBox8.TabIndex = 14;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(298, 119);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(172, 27);
            this.comboBox9.TabIndex = 13;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(45, 317);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(185, 26);
            this.textBox11.TabIndex = 12;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(45, 250);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(185, 26);
            this.textBox12.TabIndex = 11;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(45, 183);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(185, 26);
            this.textBox13.TabIndex = 10;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(45, 119);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(185, 26);
            this.textBox14.TabIndex = 9;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(45, 56);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(185, 26);
            this.textBox15.TabIndex = 8;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(45, 295);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 19);
            this.label23.TabIndex = 7;
            this.label23.Text = "Correo";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(45, 228);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(67, 19);
            this.label24.TabIndex = 6;
            this.label24.Text = "Telefono";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(45, 161);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(66, 19);
            this.label25.TabIndex = 5;
            this.label25.Text = "Apellido";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(45, 97);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 19);
            this.label26.TabIndex = 4;
            this.label26.Text = "Nombre";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(45, 34);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(33, 19);
            this.label27.TabIndex = 3;
            this.label27.Text = "DUI";
            // 
            // attendancePage
            // 
            this.attendancePage.Controls.Add(this.groupBox7);
            this.attendancePage.Controls.Add(this.dataGridView4);
            this.attendancePage.Controls.Add(this.groupBox8);
            this.attendancePage.Location = new System.Drawing.Point(4, 4);
            this.attendancePage.Name = "attendancePage";
            this.attendancePage.Padding = new System.Windows.Forms.Padding(3);
            this.attendancePage.Size = new System.Drawing.Size(1158, 484);
            this.attendancePage.TabIndex = 9;
            this.attendancePage.Text = "Asistencias";
            this.attendancePage.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button13);
            this.groupBox7.Controls.Add(this.button14);
            this.groupBox7.Controls.Add(this.button15);
            this.groupBox7.Location = new System.Drawing.Point(5, 399);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(554, 69);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Opciones";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.LightCoral;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.Firebrick;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.ForeColor = System.Drawing.SystemColors.Control;
            this.button13.Location = new System.Drawing.Point(19, 25);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(82, 31);
            this.button13.TabIndex = 6;
            this.button13.Text = "Atras";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.backMembersButton_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Red;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.ForeColor = System.Drawing.SystemColors.Control;
            this.button14.Location = new System.Drawing.Point(441, 25);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(87, 31);
            this.button14.TabIndex = 5;
            this.button14.Text = "Eliminar";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Gold;
            this.button15.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button15.Location = new System.Drawing.Point(320, 25);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(87, 31);
            this.button15.TabIndex = 4;
            this.button15.Text = "Editar";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView4.Location = new System.Drawing.Point(565, 16);
            this.dataGridView4.MultiSelect = false;
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowTemplate.Height = 25;
            this.dataGridView4.Size = new System.Drawing.Size(576, 452);
            this.dataGridView4.TabIndex = 4;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox8.Controls.Add(this.label28);
            this.groupBox8.Controls.Add(this.label29);
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.button16);
            this.groupBox8.Controls.Add(this.comboBox10);
            this.groupBox8.Controls.Add(this.comboBox11);
            this.groupBox8.Controls.Add(this.comboBox12);
            this.groupBox8.Controls.Add(this.textBox16);
            this.groupBox8.Controls.Add(this.textBox17);
            this.groupBox8.Controls.Add(this.textBox18);
            this.groupBox8.Controls.Add(this.textBox19);
            this.groupBox8.Controls.Add(this.textBox20);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.label32);
            this.groupBox8.Controls.Add(this.label33);
            this.groupBox8.Controls.Add(this.label34);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Location = new System.Drawing.Point(5, 16);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(554, 375);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "DATOS DE ASISTENCIA";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(298, 231);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 19);
            this.label28.TabIndex = 18;
            this.label28.Text = "Estado";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(298, 164);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(80, 19);
            this.label29.TabIndex = 17;
            this.label29.Text = "Instalacion";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(298, 97);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(84, 19);
            this.label30.TabIndex = 16;
            this.label30.Text = "Membresia";
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.LimeGreen;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button16.Location = new System.Drawing.Point(431, 317);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(82, 31);
            this.button16.TabIndex = 3;
            this.button16.Text = "Agregar";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(298, 253);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(172, 27);
            this.comboBox10.TabIndex = 15;
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Location = new System.Drawing.Point(298, 186);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(172, 27);
            this.comboBox11.TabIndex = 14;
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(298, 119);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(172, 27);
            this.comboBox12.TabIndex = 13;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(45, 317);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(185, 26);
            this.textBox16.TabIndex = 12;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(45, 250);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(185, 26);
            this.textBox17.TabIndex = 11;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(45, 183);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(185, 26);
            this.textBox18.TabIndex = 10;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(45, 119);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(185, 26);
            this.textBox19.TabIndex = 9;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(45, 56);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(185, 26);
            this.textBox20.TabIndex = 8;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(45, 295);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(56, 19);
            this.label31.TabIndex = 7;
            this.label31.Text = "Correo";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(45, 228);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(67, 19);
            this.label32.TabIndex = 6;
            this.label32.Text = "Telefono";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(45, 161);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(66, 19);
            this.label33.TabIndex = 5;
            this.label33.Text = "Apellido";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(45, 97);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 19);
            this.label34.TabIndex = 4;
            this.label34.Text = "Nombre";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(45, 34);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(33, 19);
            this.label35.TabIndex = 3;
            this.label35.Text = "DUI";
            // 
            // DiseñoGimnasio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1157, 508);
            this.Controls.Add(this.gymAdminTab);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DiseñoGimnasio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DiseñoGimnasio";
            ((System.ComponentModel.ISupportInitialize)(this.membersBusinessBindingSource)).EndInit();
            this.membersPage.ResumeLayout(false);
            this.membersOptionsGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.membersDataGridView)).EndInit();
            this.membersGroupBox.ResumeLayout(false);
            this.membersGroupBox.PerformLayout();
            this.instructorsPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.instructorsDataGridView)).EndInit();
            this.optionsInstructorGroupBox.ResumeLayout(false);
            this.instructorDataGroupBox.ResumeLayout(false);
            this.instructorDataGroupBox.PerformLayout();
            this.gymAdminTab.ResumeLayout(false);
            this.FacilitiesPage.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.equipmentPage.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.classesPage.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.attendancePage.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private BindingSource membersBusinessBindingSource;
        private TabPage membersPage;
        private GroupBox membersOptionsGroupBox;
        private Button backButton;
        private Button deleteButton;
        private Button editButton;
        private DataGridView membersDataGridView;
        private GroupBox membersGroupBox;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button addButton;
        private ComboBox estadosComboBox;
        private ComboBox instalacionesComboBox;
        private ComboBox membresiaComboBox;
        private TextBox emailTextBox;
        private TextBox numberPhoneTextBox;
        private TextBox lastNameTextBox;
        private TextBox nameTextBox;
        private TextBox duiMemberTextBox;
        private Label emailLabel;
        private Label numberPhoneLabel;
        private Label lastNameLabel;
        private Label nameLabel;
        private Label duiLabel;
        private TabPage instructorsPage;
        private GroupBox optionsInstructorGroupBox;
        private GroupBox instructorDataGroupBox;
        private Button addInstructorButton;
        private Button editInstructorButton;
        private Button deleteInstructorButton;
        private Label statusInstructorLabel;
        private ComboBox statusInstructorComboBox;
        private TextBox salaryInstructorTextBox;
        private Label sueldoInstructorLabel;
        private TextBox emailInstructorTextBox;
        private TextBox phoneInstructorTextBox;
        private TextBox lastNameInstructorTextBox;
        private TextBox nameInstructorTextBox;
        private Label emailInstructorLabel;
        private Label phoneInstructorLabel;
        private Label lastNameInstructorLabel;
        private Label nameInstructorLabel;
        private TabControl gymAdminTab;
        private DataGridView instructorsDataGridView;
        private Button goToEquipmentPageButton;
        private Button goToAttendancesPageButton;
        private Button goToFacilitiesPageButton;
        private Button goToClassesPageButton;
        private Button goToMembersPageButton;
        private TabPage FacilitiesPage;
        private TabPage equipmentPage;
        private TabPage classesPage;
        private TabPage attendancePage;
        private GroupBox groupBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private DataGridView dataGridView1;
        private GroupBox groupBox2;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button button4;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private ComboBox comboBox3;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private GroupBox groupBox3;
        private Button button5;
        private Button button6;
        private Button button7;
        private DataGridView dataGridView2;
        private GroupBox groupBox4;
        private Label label12;
        private Label label13;
        private Label label14;
        private Button button8;
        private ComboBox comboBox4;
        private ComboBox comboBox5;
        private ComboBox comboBox6;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private GroupBox groupBox5;
        private Button button9;
        private Button button10;
        private Button button11;
        private DataGridView dataGridView3;
        private GroupBox groupBox6;
        private Label label20;
        private Label label21;
        private Label label22;
        private Button button12;
        private ComboBox comboBox7;
        private ComboBox comboBox8;
        private ComboBox comboBox9;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private Label label27;
        private GroupBox groupBox7;
        private Button button13;
        private Button button14;
        private Button button15;
        private DataGridView dataGridView4;
        private GroupBox groupBox8;
        private Label label28;
        private Label label29;
        private Label label30;
        private Button button16;
        private ComboBox comboBox10;
        private ComboBox comboBox11;
        private ComboBox comboBox12;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox20;
        private Label label31;
        private Label label32;
        private Label label33;
        private Label label34;
        private Label label35;
    }
}