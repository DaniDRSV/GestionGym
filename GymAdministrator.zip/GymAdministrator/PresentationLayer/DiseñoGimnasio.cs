﻿using BusinessLayer.CRUD;
using CommonLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationLayer
{
    public partial class DiseñoGimnasio : Form
    {
        private bool isEditMode = false;

        public DiseñoGimnasio()
        {
            InitializeComponent();
            LoadMiembrosData();
            LoadInstructorData();
            LoadMembershipsComboBoxData();
            LoadFacilitiesComboBoxData();
            LoadStatusComboBoxData();
            LoadStatusInstructorComboBoxData();
        }

        private void LoadMiembrosData()
        {
            MembersBusiness membersBusiness = new MembersBusiness();
            membersDataGridView.DataSource = membersBusiness.GetMembers();
        }
        private void LoadInstructorData()
        {
            IntructorBusiness instructorBusiness = new IntructorBusiness();
            instructorsDataGridView.DataSource = instructorBusiness.GetIntructores();
        }


        private void clearForm()
        {
            membresiaComboBox.SelectedIndex = 0;
            instalacionesComboBox.SelectedIndex = 0;
            duiMemberTextBox.Clear();
            nameTextBox.Clear();
            lastNameTextBox.Clear();
            numberPhoneTextBox.Clear();
            emailTextBox.Clear();
            estadosComboBox.SelectedIndex = 0;
            nameInstructorTextBox.Clear();
            lastNameInstructorTextBox.Clear();
            phoneInstructorTextBox.Clear();
            emailInstructorTextBox.Clear();
            salaryInstructorTextBox.Clear();
            statusInstructorComboBox.SelectedIndex = 0;
        }

        /*
         * 
         * Start Members Page
         * 
         */

        //Cargamos los ComboBox de la pestaña de miembros
        private void LoadMembershipsComboBoxData()
        {
            MembersBusiness membersBusiness = new MembersBusiness();
            membresiaComboBox.DataSource = membersBusiness.GetMemberships();
            membresiaComboBox.DisplayMember = "tipo";
            membresiaComboBox.ValueMember = "idmembresia";
            membresiaComboBox.SelectedIndex = 2;

        }

        private void LoadStatusComboBoxData()
        {
            MembersBusiness membersBusiness = new MembersBusiness();
            estadosComboBox.DataSource = membersBusiness.GetStatus();
            estadosComboBox.DisplayMember = "nombre";
            estadosComboBox.ValueMember = "id_estado";
            estadosComboBox.SelectedIndex = 0;

        }

        private void LoadFacilitiesComboBoxData()
        {
            MembersBusiness membersBusiness = new MembersBusiness();
            instalacionesComboBox.DataSource = membersBusiness.GetFacilities();
            instalacionesComboBox.DisplayMember = "nombre";
            instalacionesComboBox.ValueMember = "idinstalacion";

        }


        //Botones de comportamiento de la pestaña usuario
        private void addButton_Click(object sender, EventArgs e)
        {
            MembersBusiness membersBusiness = new MembersBusiness();

            Members miembro = new Members();

            miembro.idMembresia = int.Parse(membresiaComboBox.SelectedValue.ToString());
            miembro.idInstalacion = int.Parse(instalacionesComboBox.SelectedValue.ToString());
            miembro.nombre = nameTextBox.Text;
            miembro.apellido = lastNameTextBox.Text;
            miembro.correo = emailTextBox.Text;
            miembro.telefono = numberPhoneTextBox.Text;
            miembro.dui = duiMemberTextBox.Text;
            miembro.estado = int.Parse(estadosComboBox.SelectedValue.ToString());


            if (isEditMode == false)
            {
                membersBusiness.AddMembers(miembro);

                LoadMiembrosData();
            }
            else
            {
                miembro.idMiembro = int.Parse(membersDataGridView.CurrentRow.Cells[0].Value.ToString());
                membersBusiness.UpdateMiembro(miembro);
                LoadMiembrosData();
                isEditMode = false;
            }

            clearForm();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
             if (membersDataGridView.SelectedRows.Count > 0)
            {
                int memberId = int.Parse(membersDataGridView.CurrentRow.Cells[0].Value.ToString());

                MembersBusiness membersBusiness = new MembersBusiness();
                Members miembro = new Members();

                miembro.idMiembro = memberId;

                membersBusiness.DeleteMiembro(miembro);
                LoadMiembrosData();
            }
            else
            {
                MessageBox.Show("Debe seleccionar una fila antes de eliminar");
            }
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            if (membersDataGridView.SelectedRows.Count > 0)
            {
                isEditMode = true;

                membresiaComboBox.SelectedValue = membersDataGridView.CurrentRow.Cells[1].Value.ToString();
                instalacionesComboBox.SelectedValue = membersDataGridView.CurrentRow.Cells[2].Value.ToString();
                duiMemberTextBox.Text = membersDataGridView.CurrentRow.Cells[3].Value.ToString();
                nameTextBox.Text = membersDataGridView.CurrentRow.Cells[4].Value.ToString();
                lastNameTextBox.Text = membersDataGridView.CurrentRow.Cells[5].Value.ToString();
                numberPhoneTextBox.Text = membersDataGridView.CurrentRow.Cells[6].Value.ToString();
                emailTextBox.Text = membersDataGridView.CurrentRow.Cells[7].Value.ToString();
                estadosComboBox.SelectedValue = membersDataGridView.CurrentRow.Cells[8].Value.ToString();
            }
            else
            {
                MessageBox.Show("Debe seleccionar una fila antes de editar");
            }

        }

        private void backMembersButton_Click(object sender, EventArgs e)
        {
            gymAdminTab.SelectedIndex = 0;
        }

        /*
        * 
        * End Members Page
        * 
        */



        /*
         * 
         * Start Instructor Page
         * 
         */
        private void LoadStatusInstructorComboBoxData()
        {
            IntructorBusiness instructorBusiness = new IntructorBusiness();
            statusInstructorComboBox.DataSource = instructorBusiness.GetStatus();
            statusInstructorComboBox.DisplayMember = "nombre";
            statusInstructorComboBox.ValueMember = "id_estado";
            statusInstructorComboBox.SelectedIndex = 0;

        }

        private void addInstructorButton_Click(object sender, EventArgs e)
        {
            IntructorBusiness instructorBusiness = new IntructorBusiness();

            Instructor instructor = new Instructor();

            instructor.nombre = nameInstructorTextBox.Text;
            instructor.apellido = lastNameInstructorTextBox.Text;
            instructor.correo = emailInstructorTextBox.Text;
            instructor.telefono = phoneInstructorTextBox.Text;
            instructor.sueldo = decimal.Parse(salaryInstructorTextBox.Text);
            instructor.estado = int.Parse(statusInstructorComboBox.SelectedValue.ToString());


            if (isEditMode == false)
            {
                instructorBusiness.AddInstructor(instructor);

                LoadInstructorData();
            }
            else
            {
                instructor.idInstructor = int.Parse(instructorsDataGridView.CurrentRow.Cells[0].Value.ToString());
                instructorBusiness.UpdateInstructor(instructor);
                LoadInstructorData();
                isEditMode = false;
            }

            clearForm();
        }

        private void editInstructorButton_Click(object sender, EventArgs e)
        {
            if (instructorsDataGridView.SelectedRows.Count > 0)
            {
                isEditMode = true;

                nameInstructorTextBox.Text = instructorsDataGridView.CurrentRow.Cells[1].Value.ToString();
                lastNameInstructorTextBox.Text = instructorsDataGridView.CurrentRow.Cells[2].Value.ToString();
                phoneInstructorTextBox.Text = instructorsDataGridView.CurrentRow.Cells[3].Value.ToString();
                emailInstructorTextBox.Text = instructorsDataGridView.CurrentRow.Cells[4].Value.ToString();
                salaryInstructorTextBox.Text = instructorsDataGridView.CurrentRow.Cells[5].Value.ToString();
                statusInstructorComboBox.SelectedValue = instructorsDataGridView.CurrentRow.Cells[6].Value.ToString();
            }
            else
            {
                MessageBox.Show("Debe seleccionar una fila antes de editar");
            }

        }

        private void deleteInstructorButton_Click(object sender, EventArgs e)
        {
            if (instructorsDataGridView.SelectedRows.Count > 0)
            {
                int instructorId = int.Parse(instructorsDataGridView.CurrentRow.Cells[0].Value.ToString());

                IntructorBusiness instructorBusiness = new IntructorBusiness();
                Instructor instructor = new Instructor();

                instructor.idInstructor = instructorId;

                instructorBusiness.DeleteInstructor(instructor);
                LoadInstructorData();
            }
            else
            {
                MessageBox.Show("Debe seleccionar una fila antes de eliminar");
            }
        }

        private void goToMembersPageButton_Click(object sender, EventArgs e)
        {
            gymAdminTab.SelectedIndex = 1;
        }

        private void goToClassesPageButton_Click(object sender, EventArgs e)
        {
            gymAdminTab.SelectedIndex = 4;
        }

        private void goToFacilitiesPageButton_Click(object sender, EventArgs e)
        {
            gymAdminTab.SelectedIndex = 2;
        }

        private void goToAttendancesPageButton_Click(object sender, EventArgs e)
        {
            gymAdminTab.SelectedIndex = 5;
        }

        private void goToEquipmentPageButton_Click(object sender, EventArgs e)
        {
            gymAdminTab.SelectedIndex = 3;
        }

        /*
        * 
        * End Members Page
        * 
        */



        /*
         * 
         * Start Instructor Page
         * 
         */
    }
}
