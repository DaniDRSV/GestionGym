﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer
{
    public class Membership
    {
        public int idMembresia { get; set; }
        public string tipo { get; set; }
        public decimal precio { get; set; }
    }
}
