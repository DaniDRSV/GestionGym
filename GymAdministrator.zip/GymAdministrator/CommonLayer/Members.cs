﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer
{
    public class Members
    {
        public int idMiembro { get; set; }
        public int idMembresia { get; set; }
        public int idInstalacion { get; set; }
        public string dui { get; set; }
        public string nombre { get; set; }
        public string apellido { get; set; }
        public string telefono { get; set; }
        public string correo { get; set; }
        public int estado { get; set; }
    }
}
