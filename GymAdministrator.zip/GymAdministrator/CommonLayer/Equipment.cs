﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer
{
    public class Equipment
    {
        public int idInstalacion { get; set; }
        public int idEquipo { get; set; }
        public int idInstalacionOriginal { get; set; } 
        public int idEquipoOriginal { get; set; }
    }
}
