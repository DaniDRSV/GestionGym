﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class statusData
    {
        Connection _connection = new Connection();
        SqlDataReader _reader;
        SqlCommand _cmd = new SqlCommand();
        DataTable statusTable = new DataTable();

        public DataTable GetAllEstados()
        {
            _cmd.Connection = _connection.OpenConnection();
            _cmd.CommandText = "SELECT * FROM estados";
            _cmd.CommandType = CommandType.Text;

            _reader = _cmd.ExecuteReader();
            statusTable.Load(_reader);

            _connection.CloseConnection();

            return statusTable;
        }
    }
}
