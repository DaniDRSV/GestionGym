﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonLayer;

namespace DataLayer
{
    public class MembershipData
    {
        Connection _connection = new Connection();
        SqlDataReader _reader;
        SqlCommand _cmd = new SqlCommand();
        DataTable membresiaTable = new DataTable();

        public DataTable GetAllMembresias()
        {
            _cmd.Connection = _connection.OpenConnection();
            _cmd.CommandText = "SELECT * FROM membresia";
            _cmd.CommandType = CommandType.Text;

            _reader = _cmd.ExecuteReader();
            membresiaTable.Load(_reader);

            _connection.CloseConnection();

            return membresiaTable;
        }
    }
}
